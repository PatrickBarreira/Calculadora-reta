 public class Ponto {
    double x, y;
    public Ponto(double x, double y) {
        this.x = x;
        this.y = y;
    }
}