import java.util.Scanner; 

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Insira as coordenadas do primeiro ponto, Formato: (x y):");
        double x1 = scanner.nextDouble();
        double y1 = scanner.nextDouble();
        
        System.out.println("Insira as coordenadas do segundo ponto, Formato: (x y):");
        double x2 = scanner.nextDouble();
        double y2 = scanner.nextDouble();
        
        Ponto ponto1 = new Ponto(x1, y1);
        Ponto ponto2 = new Ponto(x2, y2);
        
        Reta reta = new Reta(ponto1, ponto2);
        reta.imprimirEquacao();
        
        scanner.close();
    }
}