class Reta {
    Ponto p1, p2;
    double m, b;
    
        public Reta(Ponto p1, Ponto p2) {
        this.p1 = p1;
        this.p2 = p2;
        calcularM();
        calcularB();
    }    
    
    public void calcularM() {
        if (p2.x - p1.x != 0) {
            m = (p2.y - p1.y) / (p2.x - p1.x);
    } else {
        System.out.println("Erro, os pontos possuem a mesma coordenada x resultando em uma divisao por 0");
        System.exit(1);
        }
    }
    public void calcularB() {
        b = p1.y - m * p1.x;
    }
    public void imprimirEquacao() {
        System.out.println("A equação da reta é: y = " + m + "x + " + b);
    }
}

//    public void calcularM() {
      //  m = (p2.y - p1.y) / (p2.x - p1.x);